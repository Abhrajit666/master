package ab858772.foundation.bank.exception;

public class ResourceNotFoundException extends Exception {

	public ResourceNotFoundException(String msg) {
		super(msg);
	}
	
	

}
